(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();async function e(e,t=navigator.clipboard){if(!e)throw Error(`There is no text to copy.`);if(!t?.writeText)throw Error(`Clipboard API is unavailable.`);await t.writeText(e)}var t=`STEGOSAVR-PUBLIC:v1:`,n=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`;function r(e){if(!e.startsWith(`STEGOSAVR-PUBLIC:v1:`))throw Error(`Unsupported public key format.`);let t=o(e.slice(20));if(t.length!==32)throw Error(`Public key must decode to 32 bytes.`);return t}function i(e){if(e.length!==32)throw Error(`Public key must contain 32 bytes.`);return`${t}${a(e)}`}function a(e){let t=``;for(let r=0;r<e.length;r+=3){let i=e[r],a=e[r+1],o=e[r+2];t+=n[i>>2],t+=n[(i&3)<<4|(a??0)>>4],r+1<e.length&&(t+=n[(a&15)<<2|(o??0)>>6]),r+2<e.length&&(t+=n[o&63])}return t}function o(e){if(!/^[A-Za-z0-9+/]+$/.test(e))throw Error(`Public key contains invalid base64.`);let t=e.padEnd(Math.ceil(e.length/4)*4,`=`),r=[];for(let e=0;e<t.length;e+=4){let i=t.slice(e,e+4),a=[...i].map(e=>e===`=`?0:n.indexOf(e));if(a.some(e=>e<0))throw Error(`Public key contains invalid base64.`);let o=a[0]<<18|a[1]<<12|a[2]<<6|a[3];r.push(o>>16&255),i[2]!==`=`&&r.push(o>>8&255),i[3]!==`=`&&r.push(o&255)}return new Uint8Array(r)}var s=36;function c(e){let t=new Uint8Array(s);return t[0]=1,t.set(e,1),t.set(u(e),33),t}function l(e){if(e.length!==s)throw Error(`Mnemonic public key payload must contain ${s} bytes.`);let t=e[0];if(t!==1)throw Error(`Unsupported mnemonic public key version: ${t}.`);let n=new Uint8Array(e.slice(1,33));if(!f(e.slice(33),[...u(n)]))throw Error(`Mnemonic public key checksum mismatch.`);return n}function u(e){let t=new Uint8Array(1+e.length);t[0]=1,t.set(e,1);let n=d(t);return new Uint8Array([n>>>16&255,n>>>8&255,n&255])}function d(e){let t=2166136261;for(let n of e)t^=n,t=Math.imul(t,16777619);return t>>>0}function f(e,t){return e.length===t.length&&e.every((e,n)=>e===t[n])}var p={id:`solemn-kit-ru`,label:`Торжественный комплект`,marker:`🚩📰✨`,adjectives:[`алый`,`бурный`,`гулкий`,`девятый`,`железный`,`заветный`,`зубовный`,`исторический`,`кипучий`,`могучий`,`огневой`,`парадный`,`решительный`,`стальной`,`торжественный`,`ударный`],nouns:[`ваал`,`вал`,`вихрь`,`враг`,`заря`,`клич`,`конь`,`маяк`,`молох`,`песок`,`поступь`,`сердце`,`стяг`,`час`,`шаг`,`эпос`],render(e){return`${this.marker}
Передовая заметка

Пусть ${e[0]}, ${e[1]} и ${e[2]} выявляют ${e[3]}, когда ${e[4]} вершит ${e[5]}.
Вперед, товарищи строк, ибо ${e[6]}, ${e[7]}, ${e[8]} и ${e[9]} уже рдеют в газетной вышине.
Если ${e[10]} гремит, то ${e[11]} отвечает; если ${e[12]} молчит, то ${e[13]} все равно шагает.
Невзирая на отдельные ошибки, ${e[14]}, ${e[15]}, ${e[16]}, ${e[17]} и ${e[18]} несут очередной абзац.
Да здравствует ${e[19]}: ${e[20]}, ${e[21]} и ${e[22]} под клики редакции!
Пускай ${e[23]} скрежещет, пускай ${e[24]} возражает, но ${e[25]}, ${e[26]}, ${e[27]} уже стоят у края колонки.
Отсюда ${e[28]} видит ${e[29]}, а ${e[30]} записывает ${e[31]} в блокнот эпохи.
И потому ${e[32]}, ${e[33]}, ${e[34]} и ${e[35]} завершают сообщение: вперед!`}},m=16,h=[p];function ee(){return h.map(e=>({id:e.id,label:e.label}))}function g(e,t){let n=v(t);y(n);let i=[...c(r(e))].map(e=>`${n.adjectives[e>>4&15]} ${n.nouns[e&15]}`);return n.render(i)}function _(e){let t=e.trim(),n=h.find(e=>t.startsWith(e.marker));if(!n)throw Error(`Unknown grammar mnemonic theme.`);return y(n),i(l(te(t,n)))}function v(e){let t=h.find(t=>t.id===e);if(!t)throw Error(`Unknown grammar mnemonic theme: ${e}`);return t}function te(e,t){let n=new Map(t.adjectives.map((e,t)=>[e,t])),r=new Map(t.nouns.map((e,t)=>[e,t])),i=e.toLocaleLowerCase(`ru`).match(/\p{L}+/gu)??[],a=[];for(let e=0;e<i.length-1;e+=1){let t=n.get(i[e]),o=r.get(i[e+1]);t!==void 0&&o!==void 0&&(a.push(t<<4|o),e+=1)}if(a.length!==s)throw Error(`Grammar mnemonic text must contain exactly ${s} encoded adjective-noun pairs.`);return a}function y(e){if(!e.id||!e.label||!e.marker)throw Error(`Invalid grammar theme metadata for ${e.id||`unknown`}.`);b(e.adjectives,`${e.id}.adjectives`),b(e.nouns,`${e.id}.nouns`)}function b(e,t){if(e.length!==m)throw Error(`${t} must contain exactly ${m} tokens.`);if(new Set(e).size!==e.length)throw Error(`${t} must not contain duplicate tokens.`);if(e.some(e=>e!==e.toLocaleLowerCase(`ru`)))throw Error(`${t} must use lowercase tokens.`)}var x={id:`grammar-theme`,displayFormats:ee(),encode(e,t){return h.some(e=>e.id===t)?g(e,t):null},tryDecode(e){return _(e)}},ne={id:`raw`,displayFormats:[{id:`raw`,label:`Raw STEGOSAVR key`}],encode(e,t){return t===`raw`?(r(e),e):null},tryDecode(e){let t=e.trim();return r(t),t}},S=`🔐`,C=[{id:`standard`,label:`Standard mnemonic`,marker:S,adjectives:O([`quiet`,`bright`,`velvet`,`silver`,`lunar`,`patient`,`gentle`,`brave`,`crystal`,`hidden`,`rapid`,`warm`,`soft`,`clear`,`tiny`,`amber`],[`blue`,`green`,`gold`,`red`,`violet`,`white`,`black`,`orange`,`indigo`,`rose`,`mint`,`pearl`,`copper`,`frost`,`sunny`,`misty`]),nouns:O([`mango`,`archive`,`garden`,`signal`,`harbor`,`lantern`,`meadow`,`orbit`,`river`,`notebook`,`station`,`cloud`,`mirror`,`compass`,`summit`,`library`],[`field`,`bridge`,`spark`,`path`,`room`,`tower`,`stone`,`paper`,`thread`,`window`,`forest`,`shore`,`map`,`seed`,`voice`,`drift`]),emoji:k([`🌙`,`🧭`,`✨`,`📡`,`🔑`,`🪐`,`🧊`,`🌊`,`🕯️`,`🧬`,`🪞`,`🌿`,`⚡`,`🎲`,`🌺`,`🛰️`])},{id:`vegetables`,label:`Vegetables mnemonic`,marker:S,adjectives:O([`crisp`,`fresh`,`green`,`sunny`,`earthy`,`tender`,`leafy`,`golden`,`sweet`,`peppery`,`garden`,`ripe`,`bright`,`juicy`,`humble`,`rooted`],[`basil`,`carrot`,`tomato`,`onion`,`pepper`,`garlic`,`squash`,`radish`,`turnip`,`celery`,`cucumber`,`pumpkin`,`lettuce`,`parsley`,`beet`,`pea`]),nouns:O([`carrot`,`pepper`,`pumpkin`,`radish`,`tomato`,`turnip`,`lettuce`,`cabbage`,`beet`,`onion`,`garlic`,`squash`,`cucumber`,`celery`,`pea`,`herb`],[`patch`,`basket`,`sprout`,`market`,`kitchen`,`seed`,`vine`,`harvest`,`bed`,`row`,`soil`,`leaf`,`stew`,`plot`,`root`,`bunch`]),emoji:k([`🥕`,`🥬`,`🍅`,`🌽`,`🧄`,`🧅`,`🥒`,`🥦`,`🫑`,`🥔`,`🍠`,`🫛`,`🌶️`,`🎃`,`🌱`,`🪴`])}];function w(){return[...C]}function T(e){let t=C.find(t=>t.id===e);if(!t)throw Error(`Unknown mnemonic dictionary profile: ${e}`);return t}function E(e){if(!e.id||!e.label||e.marker!==`🔐`)throw Error(`Invalid mnemonic dictionary metadata for ${e.id||`unknown`}.`);D(e.adjectives,`${e.id}.adjectives`),D(e.nouns,`${e.id}.nouns`),D(e.emoji,`${e.id}.emoji`)}function D(e,t){if(e.length!==256)throw Error(`${t} must contain exactly 256 tokens.`);if(new Set(e).size!==e.length)throw Error(`${t} must not contain duplicate tokens.`)}function O(e,t){return e.flatMap(e=>t.map(t=>`${e}-${t}`))}function k(e){return e.flatMap(t=>e.map(e=>`${t}${e}`))}var A=6;function re(){return w().map(e=>({id:e.id,label:e.label}))}function ie(e,t){let n=T(t);E(n);let i=c(r(e)),a=[];for(let e=0;e<i.length;e+=A){let t=i.slice(e,e+A);a.push(oe(t,n))}return`${n.marker} ${n.id}:v1\n${a.join(`
`)}`}function ae(e){let t=e.trim().split(/\r?\n/).map(e=>e.trim()).filter(Boolean);if(t.length<2)throw Error(`Mnemonic public key phrase is incomplete.`);let{profile:n}=ce(t[0]);E(n);let r=t.slice(1).flatMap(e=>e.split(/\s+/).filter(Boolean)).map((e,t)=>se(e,t,n));if(r.length!==s)throw Error(`Mnemonic public key phrase must contain ${s} encoded tokens.`);return i(l(r))}function oe(e,t){if(e.length!==A)throw Error(`Mnemonic token lines must contain ${A} bytes.`);return[t.adjectives[e[0]],t.adjectives[e[1]],t.nouns[e[2]],t.emoji[e[3]],t.emoji[e[4]],t.emoji[e[5]]].join(` `)}function se(e,t,n){let r=t%A,i=(r<2?n.adjectives:r===2?n.nouns:n.emoji).indexOf(e);if(i===-1)throw Error(`Unknown mnemonic token: ${e}`);return i}function ce(e){let[t,n]=e.split(/\s+/);if(t!==`🔐`||!n)throw Error(`Mnemonic public key phrase has an invalid header.`);let r=n.match(/^([a-z0-9-]+):v(\d+)$/);if(!r)throw Error(`Mnemonic public key phrase has an invalid profile header.`);let[,i,a]=r;if(Number(a)!==1)throw Error(`Unsupported mnemonic public key version: ${a}.`);return{profile:T(i)}}var j=[ne,{id:`token-grid`,displayFormats:re(),encode(e,t){return w().some(e=>e.id===t)?ie(e,t):null},tryDecode(e){return ae(e)}},x];function le(){return j.flatMap(e=>e.displayFormats)}function ue(e,t){for(let n of j){let r=n.encode(e,t);if(r!==null)return r}throw Error(`Unknown public key display format: ${t}`)}function de(e){for(let t of j)try{let n=t.tryDecode(e);if(n!==null)return n}catch{continue}throw Error(`Recipient public key could not be decoded.`)}var M=`stegosavr.publicKey`,N=`stegosavr.protectedPrivateKey`;function fe(e=localStorage){let t=e.getItem(M),n=e.getItem(N);return!t||!n?null:{publicKey:t,protectedPrivateKey:n}}function pe(e,t=localStorage){t.setItem(M,e.publicKey),t.setItem(N,e.protectedPrivateKey)}var P=16,F=[{id:`solemn-kit-ru`,label:`Торжественный комплект`,marker:`🚩📰🧵`,chunkSize:18,adjectives:[`алый`,`бурный`,`гулкий`,`девятый`,`железный`,`заветный`,`зубовный`,`исторический`,`кипучий`,`могучий`,`огневой`,`парадный`,`решительный`,`стальной`,`торжественный`,`ударный`],nouns:[`ваал`,`вал`,`вихрь`,`враг`,`заря`,`клич`,`конь`,`маяк`,`молох`,`песок`,`поступь`,`сердце`,`стяг`,`час`,`шаг`,`эпос`],intro:`Передовая лента`,renderChunk(e,t){let n=[...e,...Array.from({length:this.chunkSize-e.length},()=>`редакционный шум`)];return`Выпуск ${t+1}. Пусть ${n[0]}, ${n[1]} и ${n[2]} выявляют ${n[3]}, когда ${n[4]} вершит ${n[5]}.
Вперед, ибо ${n[6]}, ${n[7]}, ${n[8]}, ${n[9]}, ${n[10]} и ${n[11]} уже рдеют в строке.
Пускай ${n[12]} спорит, но ${n[13]}, ${n[14]}, ${n[15]}, ${n[16]} и ${n[17]} завершают абзац.`},outro:`Конец сообщения: вперед!`}],me={id:`chunked-grammar`,displayFormats:he(),encodeEnvelopeBytes(e,t){let n=F.find(e=>e.id===t);return n?ge(e,n):null},tryDecodeEnvelopeBytes(e){return _e(e)}};function he(){return F.map(e=>({id:e.id,label:e.label}))}function ge(e,t){I(t);let n=[...e].map(e=>`${t.adjectives[e>>4&15]} ${t.nouns[e&15]}`),r=[];for(let e=0;e<n.length;e+=t.chunkSize)r.push(t.renderChunk(n.slice(e,e+t.chunkSize),e/t.chunkSize));return`${t.marker}
${t.intro}

${r.join(`

`)}

${t.outro}`}function _e(e){let t=e.trim(),n=F.find(e=>t.startsWith(e.marker));if(!n)throw Error(`Unknown styled grammar theme.`);I(n);let r=new Map(n.adjectives.map((e,t)=>[e,t])),i=new Map(n.nouns.map((e,t)=>[e,t])),a=t.toLocaleLowerCase(`ru`).match(/\p{L}+/gu)??[],o=[];for(let e=0;e<a.length-1;e+=1){let t=r.get(a[e]),n=i.get(a[e+1]);t!==void 0&&n!==void 0&&(o.push(t<<4|n),e+=1)}if(o.length===0)throw Error(`Styled grammar text does not contain encoded pairs.`);return new Uint8Array(o)}function I(e){if(!e.id||!e.label||!e.marker||!e.intro||!e.outro)throw Error(`Invalid styled grammar theme metadata for ${e.id||`unknown`}.`);if(e.chunkSize<=0)throw Error(`${e.id}.chunkSize must be positive.`);L(e.adjectives,`${e.id}.adjectives`),L(e.nouns,`${e.id}.nouns`)}function L(e,t){if(e.length!==P)throw Error(`${t} must contain exactly ${P} tokens.`);if(new Set(e).size!==e.length)throw Error(`${t} must not contain duplicate tokens.`);if(e.some(e=>e!==e.toLocaleLowerCase(`ru`)))throw Error(`${t} must use lowercase tokens.`)}var R=`encrypted-message`,z=new Uint8Array([83,71,83,84]),B=4,V=z.length+1+1+4,H={[R]:1},ve=new Map(Object.entries(H).map(([e,t])=>[t,e]));function ye(e){let t=H[e.kind],n=new Uint8Array(V+e.payload.length+B);return n.set(z,0),n[z.length]=1,n[z.length+1]=t,U(n,z.length+2,e.payload.length),n.set(e.payload,V),U(n,V+e.payload.length,G(n.slice(0,-4))),n}function be(e){if(e.length<V+B)throw Error(`Styled envelope is too short.`);for(let t=0;t<z.length;t+=1)if(e[t]!==z[t])throw Error(`Styled envelope has an invalid magic header.`);let t=e[z.length];if(t!==1)throw Error(`Unsupported styled envelope version: ${t}.`);let n=ve.get(e[z.length+1]);if(!n)throw Error(`Unsupported styled envelope kind.`);let r=W(e,z.length+2),i=V+r+B;if(e.length!==i)throw Error(`Styled envelope length mismatch.`);if(W(e,V+r)!==G(e.slice(0,-4)))throw Error(`Styled envelope checksum mismatch.`);return{kind:n,payload:e.slice(V,V+r)}}function U(e,t,n){e[t]=n>>>24&255,e[t+1]=n>>>16&255,e[t+2]=n>>>8&255,e[t+3]=n&255}function W(e,t){return e[t]*16777216+(e[t+1]<<16|e[t+2]<<8|e[t+3])}function G(e){let t=2166136261;for(let n of e)t^=n,t=Math.imul(t,16777619);return t>>>0}var K=16,q={id:`grand-chronicle-ru`,label:`Большая хроника`,marker:`📜🕯️🏛️`,chunkSize:24,epithets:[`бирюзовый`,`вечерний`,`гранитный`,`дальний`,`зеркальный`,`искристый`,`кружевной`,`лазурный`,`медовый`,`небесный`,`орнаментальный`,`перламутровый`,`северный`,`тихий`,`узорчатый`,`янтарный`],symbols:[`архив`,`берег`,`венец`,`голос`,`дворец`,`жезл`,`звон`,`исток`,`камень`,`ларец`,`мост`,`оберег`,`парус`,`родник`,`свиток`,`херес`],subject:`Крым`,intro:`Летописная запись`,renderSection(e,t){let n=[...e,...Array.from({length:this.chunkSize-e.length},()=>`пустынная строка`)];return`${this.subject} — ${n[0]}. ${this.subject} — ${n[1]}. ${this.subject} — ${n[2]}, озаривший страницы воображаемой летописи. ${this.subject} — ${n[3]}, ${n[4]} и ${n[5]}, поднятые над площадью памяти.

Сегодня ${this.subject.toLocaleLowerCase(`ru`)} хранит ${n[6]}, встречает ${n[7]}, раскрывает ${n[8]} и бережёт ${n[9]}. К нему идут ${n[10]} и ${n[11]}, над ним кружатся ${n[12]}, под ним звучит ${n[13]}, а в дальних окнах мерцают ${n[14]} и ${n[15]}.

Хвала хранителям, несущим ${n[16]}. Хвала переписчикам, выводящим ${n[17]}. Хвала мастерам, поднимающим ${n[18]}. Хвала путникам, различающим ${n[19]}. Хвала тем, кто в час ${t+1} собирает ${n[20]}, ${n[21]}, ${n[22]} и ${n[23]} в единую хронику.`},outro:`Так завершается воображаемая запись, и свиток закрывается без шума.`},xe={id:`grand-chronicle`,displayFormats:Se(),encodeEnvelopeBytes(e,t){return t===q.id?Ce(e,q):null},tryDecodeEnvelopeBytes(e){return we(e,q)}};function Se(){return[{id:q.id,label:q.label}]}function Ce(e,t){J(t);let n=[...e].map(e=>`${t.epithets[e>>4&15]} ${t.symbols[e&15]}`),r=[];for(let e=0;e<n.length;e+=t.chunkSize)r.push(t.renderSection(n.slice(e,e+t.chunkSize),e/t.chunkSize));return`${t.marker}
${t.intro}

${r.join(`

`)}

${t.outro}`}function we(e,t){let n=e.trim();if(!n.startsWith(t.marker))throw Error(`Unknown grand chronicle theme.`);J(t);let r=new Map(t.epithets.map((e,t)=>[e,t])),i=new Map(t.symbols.map((e,t)=>[e,t])),a=n.toLocaleLowerCase(`ru`).match(/\p{L}+/gu)??[],o=[];for(let e=0;e<a.length-1;e+=1){let t=r.get(a[e]),n=i.get(a[e+1]);t!==void 0&&n!==void 0&&(o.push(t<<4|n),e+=1)}if(o.length===0)throw Error(`Grand chronicle text does not contain encoded pairs.`);return new Uint8Array(o)}function J(e){if(!e.id||!e.label||!e.marker||!e.subject||!e.intro||!e.outro)throw Error(`Invalid grand chronicle theme metadata for ${e.id||`unknown`}.`);if(e.chunkSize<=0)throw Error(`${e.id}.chunkSize must be positive.`);Te(e.epithets,`${e.id}.epithets`),Te(e.symbols,`${e.id}.symbols`)}function Te(e,t){if(e.length!==K)throw Error(`${t} must contain exactly ${K} tokens.`);if(new Set(e).size!==e.length)throw Error(`${t} must not contain duplicate tokens.`);if(e.some(e=>e!==e.toLocaleLowerCase(`ru`)))throw Error(`${t} must use lowercase tokens.`)}var Ee=new TextEncoder,De=new TextDecoder,Y=[me,xe];function Oe(){return[{id:`raw`,label:`Raw encrypted message`},...Y.flatMap(e=>e.displayFormats)]}function ke(e,t){if(t===`raw`)return X(e);let n=ye({kind:R,payload:Ee.encode(X(e))});for(let e of Y){let r=e.encodeEnvelopeBytes(n,t);if(r!==null)return r}throw Error(`Unknown encrypted message display format: ${t}`)}function Ae(e){let t=e.trim();if(t.startsWith(`STEGOSAVR-MSG:v1:`))return X(t);for(let e of Y)try{let n=e.tryDecodeEnvelopeBytes(t);if(n===null)continue;let r=be(n);if(r.kind!==`encrypted-message`)throw Error(`Styled envelope does not contain an encrypted message.`);return X(De.decode(r.payload))}catch{continue}throw Error(`Encrypted message could not be decoded.`)}function X(e){let t=e.trim();if(!t.startsWith(`STEGOSAVR-MSG:v1:`))throw Error(`Unsupported encrypted message format.`);return t}var Z=`1.0.0`,je=`modulepreload`,Me=function(e,t){return new URL(e,t).href},Ne={},Pe=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=Me(t,n),t in Ne)return;Ne[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:je,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},Fe=null;async function Q(){return Fe||=await Pe(()=>import(`./crypto-DxbNOZGX.js`),[],import.meta.url),Fe}function $(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`)}function Ie(e,t){e.innerHTML=`
    <section class="app-panel" aria-labelledby="app-title">
      <header class="hero">
        <p class="eyebrow">Потный вал вдохновенья</p>
        <h1 id="app-title">Остапа несло</h1>
      </header>
      <p class="error" role="alert" style="margin-top:1.5rem">
        <strong>Extension failed to load.</strong><br/><br/>
        ${$(t instanceof Error?t.message:String(t))}<br/><br/>
        Try reloading the extension. If the problem persists, rebuild with:<br/>
        <code style="font-size:0.8em">cd extensions/chrome &amp;&amp; ./build.sh --clean</code>
      </p>
      <footer class="version-footer" aria-label="Version">
        <span class="version-label">v${Z}</span>
      </footer>
    </section>
  `}function Le(){let t=document.querySelector(`#app`);if(!t)throw Error(`Missing #app element`);let n=t,r={activeTab:`key`,storedKeyPair:fe(),keyMessage:``,publicKeyFormat:`raw`,encryptError:``,encryptedMessage:``,encryptedMessageFormat:`raw`,decryptError:``,decryptedMessage:``,initError:null};function i(){n.innerHTML=`
      <section class="app-panel" aria-labelledby="app-title">
        <header class="hero">
          <p class="eyebrow">Потный вал вдохновенья</p>
          <h1 id="app-title">Остапа несло</h1>
          <p class="lede">
  НЕЗАМЕНИМОЕ ПОСОБИЕ ДЛЯ СОЧИНЕНИЯ ЮБИЛЕЙНЫХ СТАТЕЙ,
  ТАБЕЛЬНЫХ ФЕЛЬЕТОНОВ, А ТАКЖЕ ПАРАДНЫХ СТИХОТВОРЕНИЙ. ОД И ТРОПАРЕЙ
          </p>
        </header>

        <nav class="tabs" aria-label="Encryption workflows">
          ${a(`key`,`My key`)}
          ${a(`encrypt`,`Encrypt`)}
          ${a(`decrypt`,`Decrypt`)}
        </nav>

        <div class="tab-panel">
          ${o()}
        </div>

        <footer class="version-footer" aria-label="Version">
          <span class="version-label">v${Z}</span>
        </footer>
      </section>
    `,m(),h()}function a(e,t){return`
      <button
        type="button"
        class="tab-button"
        data-tab="${e}"
        aria-selected="${r.activeTab===e}"
      >
        ${t}
      </button>
    `}function o(){return r.activeTab===`key`?s():r.activeTab===`encrypt`?c():l()}function s(){return r.initError?`
        <section class="workflow" aria-labelledby="key-title">
          <h2 id="key-title">Initialization error</h2>
          <p class="error" role="alert">${$(r.initError)}</p>
          <p class="helper">Try reloading the extension. If the problem persists, rebuild with <code>./build.sh --clean</code>.</p>
        </section>
      `:r.storedKeyPair?`
      <section class="workflow" aria-labelledby="key-title">
        <h2 id="key-title">Your public key</h2>
        <p class="helper">
          Share this public key with someone who wants to encrypt a message for you.
          Key replacement, private-key export, and private-key import are intentionally unavailable in this MVP.
        </p>
        <label>
          Public key format
          <select name="publicKeyFormat" data-public-key-format>
            ${ee()}
          </select>
        </label>
        <textarea readonly rows="8">${$(g())}</textarea>
        <div class="actions">
          <button type="button" data-copy="public-key">Copy public key</button>
        </div>
        ${f(r.keyMessage)}
      </section>
    `:`
        <section class="workflow" aria-labelledby="key-title">
          <h2 id="key-title">Create your local key</h2>
          <p class="helper">
            Your private key is protected with this passphrase before it is saved in localStorage.
            There is no recovery if you forget it.
          </p>
          <form data-form="key" class="form-grid">
            <label>
              Passphrase
              <input name="passphrase" type="password" autocomplete="new-password" required />
            </label>
            <button type="submit">Generate key</button>
          </form>
          ${f(r.keyMessage)}
        </section>
      `}function c(){return`
      <section class="workflow" aria-labelledby="encrypt-title">
        <h2 id="encrypt-title">Encrypt a message</h2>
        <p class="helper">
          Paste the recipient's Stegosavr public key and the message you want only them to read.
        </p>
        <form data-form="encrypt" class="form-grid">
          <label>
            Recipient public key
            <textarea name="recipientPublicKey" rows="5"></textarea>
          </label>
          <label>
            Message
            <textarea name="plaintext" rows="6"></textarea>
          </label>
          <button type="submit">Encrypt message</button>
        </form>
        ${p(r.encryptError)}
        ${d()}
      </section>
    `}function l(){return r.storedKeyPair?`
      <section class="workflow" aria-labelledby="decrypt-title">
        <h2 id="decrypt-title">Decrypt a message</h2>
        <p class="helper">
          Paste a Stegosavr encrypted message and enter your passphrase to unlock your local private key.
        </p>
        <form data-form="decrypt" class="form-grid">
          <label>
            Encrypted message
            <textarea name="encryptedMessage" rows="6"></textarea>
          </label>
          <label>
            Passphrase
            <input name="passphrase" type="password" autocomplete="current-password" />
          </label>
          <button type="submit">Decrypt message</button>
        </form>
        ${p(r.decryptError)}
        ${u(`Plaintext`,r.decryptedMessage)}
      </section>
    `:`
        <section class="workflow" aria-labelledby="decrypt-title">
          <h2 id="decrypt-title">Decrypt a message</h2>
          <p class="empty-state">Generate your local key before decrypting messages addressed to you.</p>
        </section>
      `}function u(e,t,n){return t?`
      <div class="output">
        <div class="output-header">
          <h3>${e}</h3>
          ${n?`<button type="button" data-copy="${n}">Copy</button>`:``}
        </div>
        <textarea readonly rows="7">${$(t)}</textarea>
      </div>
    `:``}function d(){return r.encryptedMessage?`
      <div class="output">
        <div class="output-header">
          <h3>Encrypted message</h3>
          <button type="button" data-copy="encrypted-message">Copy</button>
        </div>
        <label>
          Encrypted message format
          <select name="encryptedMessageFormat" data-encrypted-message-format>
            ${_()}
          </select>
        </label>
        <textarea readonly rows="7">${$(v())}</textarea>
      </div>
    `:``}function f(e){return e?`<p class="notice" role="status">${$(e)}</p>`:``}function p(e){return e?`<p class="error" role="alert">${$(e)}</p>`:``}function m(){n.querySelectorAll(`[data-tab]`).forEach(e=>{e.addEventListener(`click`,()=>{r.activeTab=e.dataset.tab,i()})})}function h(){n.querySelector(`[data-form="key"]`)?.addEventListener(`submit`,te),n.querySelector(`[data-form="encrypt"]`)?.addEventListener(`submit`,y),n.querySelector(`[data-form="decrypt"]`)?.addEventListener(`submit`,ne),n.querySelector(`[data-public-key-format]`)?.addEventListener(`change`,b),n.querySelector(`[data-encrypted-message-format]`)?.addEventListener(`change`,x),n.querySelector(`[data-copy="public-key"]`)?.addEventListener(`click`,()=>{S(g(),`Public key copied.`)}),n.querySelector(`[data-copy="encrypted-message"]`)?.addEventListener(`click`,()=>{S(v(),`Encrypted message copied.`)})}function ee(){return le().map(e=>`
          <option value="${e.id}" ${r.publicKeyFormat===e.id?`selected`:``}>
            ${e.label}
          </option>
        `).join(``)}function g(){return r.storedKeyPair?ue(r.storedKeyPair.publicKey,r.publicKeyFormat):``}function _(){return Oe().map(e=>`
          <option value="${e.id}" ${r.encryptedMessageFormat===e.id?`selected`:``}>
            ${e.label}
          </option>
        `).join(``)}function v(){return r.encryptedMessage?ke(r.encryptedMessage,r.encryptedMessageFormat):``}async function te(e){e.preventDefault();let t=e.currentTarget,n=C(t,`passphrase`);if(!n){r.keyMessage=`Passphrase is required.`,i();return}try{r.keyMessage=`Generating key...`,i();let e=await(await Q()).createKeyPair(n);pe(e),r.storedKeyPair=e,r.keyMessage=`Key generated and saved locally.`}catch(e){r.keyMessage=e instanceof Error?e.message:`Key generation failed. Please try again.`}i()}async function y(e){e.preventDefault();let t=e.currentTarget,n=C(t,`recipientPublicKey`),a=C(t,`plaintext`);if(r.encryptError=``,r.encryptedMessage=``,!n){r.encryptError=`Recipient public key is required.`,i();return}if(!a){r.encryptError=`A message is required.`,i();return}try{r.encryptedMessage=await(await Q()).encryptForRecipient({recipientPublicKey:n,plaintext:a}),r.encryptedMessageFormat=`raw`}catch(e){r.encryptError=e instanceof Error?e.message:`Encryption failed. The recipient public key could not be decoded.`}i()}function b(e){r.publicKeyFormat=e.currentTarget.value,r.keyMessage=``,i()}function x(e){r.encryptedMessageFormat=e.currentTarget.value,i()}async function ne(e){if(e.preventDefault(),!r.storedKeyPair){r.decryptError=`Generate a local key before decrypting messages.`,i();return}let t=e.currentTarget,n=C(t,`encryptedMessage`),a=C(t,`passphrase`);if(r.decryptError=``,r.decryptedMessage=``,!n){r.decryptError=`An encrypted message is required.`,i();return}if(!a){r.decryptError=`Passphrase is required.`,i();return}try{r.decryptedMessage=await(await Q()).decryptStoredMessage({protectedPrivateKey:r.storedKeyPair.protectedPrivateKey,passphrase:a,encryptedMessage:n})}catch(e){r.decryptError=e instanceof Error?e.message:`Decryption failed. Check the passphrase and encrypted message.`}i()}async function S(t,n){try{await e(t),r.keyMessage=n}catch{r.keyMessage=`Copy failed. Select the text and copy it manually.`}i()}function C(e,t){let n=new FormData(e).get(t);return typeof n==`string`?n.trim():``}i()}try{Le()}catch(e){let t=document.querySelector(`#app`);if(t)Ie(t,e);else throw e}export{de as n,Ae as t};